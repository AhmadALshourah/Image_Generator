// statsPage.jsx — Stats route: KPI cards, daily bar chart, distributions. Exported to window.

function StatCard({ label, value, hint, color, icon, index }) {
  const grad = {
    indigo: 'from-indigo-500/15 to-indigo-500/5 ring-indigo-200/60 dark:ring-indigo-500/20 text-indigo-600 dark:text-indigo-300',
    violet: 'from-violet-500/15 to-violet-500/5 ring-violet-200/60 dark:ring-violet-500/20 text-violet-600 dark:text-violet-300',
    emerald: 'from-emerald-500/15 to-emerald-500/5 ring-emerald-200/60 dark:ring-emerald-500/20 text-emerald-600 dark:text-emerald-300',
    amber: 'from-amber-500/15 to-amber-500/5 ring-amber-200/60 dark:ring-amber-500/20 text-amber-600 dark:text-amber-300',
  };
  return (
    <div className={`anim-fadeUp relative overflow-hidden rounded-2xl bg-gradient-to-br ${grad[color]} ring-1 bg-white dark:bg-slate-900 p-5`}
      style={{ animationDelay: `${index * 0.06}s` }}>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</span>
        <span className="opacity-80">{icon}</span>
      </div>
      <p className="mt-3 text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{hint}</p>}
    </div>
  );
}

function BarChart() {
  const { t } = useApp();
  const max = Math.max(...STATS.daily.map((d) => d.spend), 0.001);
  return (
    <div className="rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-800 shadow-sm p-5 sm:p-6 anim-fadeUp" style={{ animationDelay: '.1s' }}>
      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-4">{t('dailySpend')}</h3>
      <div className="space-y-1.5 max-h-[22rem] overflow-y-auto thin-scroll pe-1">
        {STATS.daily.map((d, i) => {
          const pct = (d.spend / max) * 100;
          return (
            <div key={i} className="flex items-center gap-3 group">
              <span className="w-12 shrink-0 text-xs font-mono text-slate-400 dark:text-slate-500">{d.date}</span>
              <div className="flex-1 h-6 rounded-md bg-slate-100 dark:bg-slate-800/60 overflow-hidden relative">
                <div className="h-full rounded-md flex items-center transition-all duration-700 ease-out"
                  style={{ width: `max(${pct}%, ${d.spend > 0 ? 12 : 0}%)`, ...brandGrad, transitionDelay: `${i * 12}ms` }}>
                  {d.spend > 0 && <span className="text-[10px] font-semibold text-white/95 px-2 whitespace-nowrap">${d.spend.toFixed(2)} · {d.imgs} img</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Distribution({ title, rows, total, delay }) {
  const palette = ['var(--brand-1)', 'var(--brand-2)', 'var(--brand-soft)', '#a78bfa'];
  return (
    <div className="rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-800 shadow-sm p-5 sm:p-6 anim-fadeUp" style={{ animationDelay: delay }}>
      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-4">{title}</h3>
      <div className="space-y-3.5">
        {rows.map((r, i) => {
          const pct = Math.round((r.count / total) * 100);
          return (
            <div key={r.label}>
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="text-slate-600 dark:text-slate-300 font-mono">{r.label}</span>
                <span className="text-slate-400 dark:text-slate-500 tabular-nums">{r.count} · {pct}%</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700 ease-out" style={{ width: `${pct}%`, backgroundColor: palette[i % palette.length], transitionDelay: `${i * 80}ms` }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StatsPage() {
  const { t } = useApp();
  const k = STATS.kpis;
  const qTotal = STATS.byQuality.reduce((a, b) => a + b.count, 0);
  const sTotal = STATS.bySize.reduce((a, b) => a + b.count, 0);
  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      <div className="mb-6 anim-fadeUp">
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">{t('usageCost')}</h1>
        <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">{t('usageSub')}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard index={0} color="indigo" label={t('imagesGenerated')} value={k.generated} icon={<IconImage size={20} />} />
        <StatCard index={1} color="violet" label={t('totalSpend')} value={'$' + k.spend.toFixed(2)} hint="USD" icon={<IconChart size={20} />} />
        <StatCard index={2} color="emerald" label={t('cacheHits')} value={k.cacheHits} hint={`≈ $${k.cacheSaved.toFixed(2)} ${t('saved2')}`} icon={<IconLayers size={20} />} />
        <StatCard index={3} color="amber" label={t('autoTranslated')} value={k.translated} icon={<IconGlobe size={20} />} />
      </div>

      <div className="mb-6">
        <BarChart />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <Distribution title={t('byQuality')} rows={STATS.byQuality} total={qTotal} delay=".12s" />
        <Distribution title={t('bySize')} rows={STATS.bySize} total={sTotal} delay=".18s" />
      </div>
    </main>
  );
}

Object.assign(window, { StatsPage });
