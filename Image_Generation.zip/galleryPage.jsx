// galleryPage.jsx — Gallery route + image modal. Exported to window.

const ASPECT = { square: 'aspect-square', portrait: 'aspect-[4/5]', landscape: 'aspect-[16/10]' };

/* ---- image card ---- */
function ImageCard({ img, onOpen, index }) {
  return (
    <button onClick={() => onOpen(img)}
      className="group text-start anim-fadeUp"
      style={{ animationDelay: `${Math.min(index, 8) * 0.04}s` }}>
      <div className={`relative ${ASPECT[img.ratio]} w-full rounded-xl overflow-hidden ring-1 ring-slate-200 dark:ring-slate-800 shadow-sm group-hover:shadow-xl group-hover:shadow-slate-300/40 dark:group-hover:shadow-black/50 transition-all duration-300 group-hover:-translate-y-1`}>
        <Art seed={img.seed} hue={img.hue} dark className="absolute inset-0" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        {img.cached && <span className="absolute top-2 end-2"><Badge color="amber">cached</Badge></span>}
      </div>
      <div className="px-0.5 pt-2.5">
        <p dir="auto" className="text-sm text-slate-700 dark:text-slate-200 leading-snug line-clamp-2">{img.prompt}</p>
        <div className="mt-1.5 flex items-center gap-2 text-xs text-slate-400 dark:text-slate-500">
          <span>{img.date}</span>
          {img.translated && <Badge color="amber">AR→EN</Badge>}
          <span className="ms-auto font-mono">{img.size}</span>
        </div>
      </div>
    </button>
  );
}

/* ---- modal ---- */
function ImageModal({ img, onClose, pushToast }) {
  const { t } = useApp();
  const [tags, setTags] = useState(img.tags);
  const [newTag, setNewTag] = useState('');
  const [confirmDel, setConfirmDel] = useState(false);

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, []);

  const addTag = (e) => {
    e.preventDefault();
    const v = newTag.trim().replace(/^#/, '');
    if (v && !tags.includes(v)) { setTags([...tags, v]); pushToast(null, 'info', `Added #${v}`); }
    setNewTag('');
  };

  const meta = [
    { label: t('size'), value: img.size, color: 'indigo' },
    { label: t('quality'), value: img.quality, color: 'violet' },
    { label: t('background'), value: img.background, color: 'fuchsia' },
    { label: t('format'), value: img.format, color: 'slate' },
    { label: t('cost'), value: '≈ $' + img.cost.toFixed(3), color: 'emerald' },
  ];

  return (
    <div className="fixed inset-0 z-50 anim-fadeIn" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute inset-0 grid place-items-center p-0 sm:p-6 pointer-events-none">
        <div className="anim-scaleIn pointer-events-auto relative w-full sm:max-w-4xl h-full sm:h-auto sm:max-h-[88vh] bg-white dark:bg-slate-900 sm:rounded-2xl shadow-2xl ring-1 ring-slate-200 dark:ring-slate-800 overflow-hidden flex flex-col sm:flex-row">
          {/* image */}
          <div className="relative sm:w-[58%] shrink-0 bg-slate-100 dark:bg-slate-950">
            <Art seed={img.seed} hue={img.hue} dark animate className={`relative w-full ${ASPECT[img.ratio]} sm:h-full sm:aspect-auto`} style={{ minHeight: '14rem' }} />
          </div>
          {/* details */}
          <div className="flex-1 min-w-0 flex flex-col">
            <div className="flex-1 overflow-y-auto thin-scroll p-5 sm:p-6">
              <p dir="auto" className="text-[15px] leading-relaxed text-slate-800 dark:text-slate-100 font-medium">{img.prompt}</p>
              {img.translated && (
                <div className="mt-3 rounded-xl bg-amber-50 dark:bg-amber-500/10 ring-1 ring-amber-200 dark:ring-amber-500/25 px-3.5 py-2.5">
                  <p className="text-xs font-semibold text-amber-600 dark:text-amber-300 mb-1">✦ {t('translatedTo')}</p>
                  <p className="text-sm text-amber-700 dark:text-amber-200" dir="ltr">{img.translated.en}</p>
                </div>
              )}

              {/* tag editor */}
              <div className="mt-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500 mb-2">{t('tags')}</p>
                <div className="flex flex-wrap gap-2 items-center">
                  {tags.map((tg) => (
                    <span key={tg} className="anim-scaleIn inline-flex items-center gap-1 rounded-full bg-slate-100 dark:bg-slate-800 ring-1 ring-slate-200 dark:ring-slate-700 ps-3 pe-1.5 py-1 text-sm text-slate-600 dark:text-slate-300">
                      #{tg}
                      <button onClick={() => setTags(tags.filter((x) => x !== tg))} aria-label={`Remove ${tg}`}
                        className="grid place-items-center h-5 w-5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400"><IconX size={12} /></button>
                    </span>
                  ))}
                  <form onSubmit={addTag}>
                    <input value={newTag} onChange={(e) => setNewTag(e.target.value)} placeholder={t('addTag')}
                      className="w-28 rounded-full bg-transparent ring-1 ring-dashed ring-slate-300 dark:ring-slate-700 px-3 py-1 text-sm text-slate-600 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-solid"
                      style={{ '--tw-ring-color': 'var(--ring)' }} />
                  </form>
                </div>
              </div>

              {/* badges */}
              <div className="mt-5 flex flex-wrap gap-2">
                {meta.map((m) => (
                  <Badge key={m.label} color={m.color}>{m.label}: {m.value}</Badge>
                ))}
              </div>

              {/* metadata */}
              <dl className="mt-5 grid grid-cols-2 gap-y-2.5 gap-x-4 text-sm">
                <dt className="text-slate-400 dark:text-slate-500 flex items-center gap-1.5"><IconClock size={14} /> {t('created')}</dt>
                <dd className="text-slate-700 dark:text-slate-200 text-end font-mono">{img.date}</dd>
                <dt className="text-slate-400 dark:text-slate-500 flex items-center gap-1.5"><IconLayers size={14} /> {t('fileSize')}</dt>
                <dd className="text-slate-700 dark:text-slate-200 text-end font-mono">{img.fileSize}</dd>
              </dl>
            </div>

            {/* actions */}
            <div className="border-t border-slate-200 dark:border-slate-800 p-4 grid grid-cols-2 gap-2.5">
              <Btn variant="outline" size="sm" icon={<IconDownload size={16} />} onClick={() => pushToast('downloadStarted', 'success')}>{t('download')}</Btn>
              <Btn variant="outline" size="sm" icon={<IconShare size={16} />} onClick={() => pushToast('linkCopied', 'success')}>{t('share')}</Btn>
              <Btn size="sm" icon={<IconRefresh size={16} />} onClick={() => pushToast(null, 'info', 'Sent to Create with this prompt.')}>{t('regenSimilar')}</Btn>
              <Btn variant="danger" size="sm" icon={<IconTrash size={16} />}
                onClick={() => { if (confirmDel) { pushToast('deleted', 'error'); onClose(); } else { setConfirmDel(true); setTimeout(() => setConfirmDel(false), 2600); } }}>
                {confirmDel ? t('confirmDelete') : t('delete')}
              </Btn>
            </div>
          </div>

          <button onClick={onClose} aria-label="Close"
            className="absolute top-3 end-3 grid place-items-center h-9 w-9 rounded-full bg-white/80 dark:bg-slate-900/80 backdrop-blur ring-1 ring-slate-200 dark:ring-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-slate-100 transition-colors">
            <IconX size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---- mini select ---- */
function MiniSelect({ value, onChange, options }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}
      className="h-9 rounded-lg bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-800 px-3 text-sm text-slate-600 dark:text-slate-300 focus:outline-none focus:ring-2"
      style={{ '--tw-ring-color': 'var(--ring)' }}>
      {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
  );
}

function GalleryPage({ onNavigate, pushToast }) {
  const { t } = useApp();
  const [query, setQuery] = useState('');
  const [size, setSize] = useState('');
  const [quality, setQuality] = useState('');
  const [bg, setBg] = useState('');
  const [activeTags, setActiveTags] = useState([]);
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState(null);
  const PER = 12;

  const toggleTag = (tag) => { setActiveTags((p) => p.includes(tag) ? p.filter((x) => x !== tag) : [...p, tag]); setPage(0); };
  const anyFilter = query || size || quality || bg || activeTags.length;
  const clear = () => { setQuery(''); setSize(''); setQuality(''); setBg(''); setActiveTags([]); setPage(0); };

  const filtered = GALLERY.filter((g) => {
    if (query && !(g.prompt + (g.translated ? g.translated.en : '')).toLowerCase().includes(query.toLowerCase())) return false;
    if (size && g.size !== size) return false;
    if (quality && g.quality !== quality) return false;
    if (bg && g.background !== bg) return false;
    if (activeTags.length && !activeTags.every((tg) => g.tags.includes(tg))) return false;
    return true;
  });

  const pages = Math.max(1, Math.ceil(filtered.length / PER));
  const view = filtered.slice(page * PER, page * PER + PER);

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {/* header */}
      <div className="flex items-end justify-between gap-4 mb-5 anim-fadeUp">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">{t('gallery')}</h1>
          <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">{GALLERY.length} {t('galleryCount')}</p>
        </div>
        <Btn onClick={() => onNavigate('create')} icon={<IconPlus size={18} />}>{t('newImage')}</Btn>
      </div>

      {/* search + filter card */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-800 shadow-sm p-4 sm:p-5 mb-6 anim-fadeUp" style={{ animationDelay: '.05s' }}>
        <div className="relative">
          <span className="absolute start-3.5 top-1/2 -translate-y-1/2 text-slate-400"><IconSearch size={18} /></span>
          <input value={query} onChange={(e) => { setQuery(e.target.value); setPage(0); }} placeholder={t('searchPh')}
            dir="auto" className="w-full h-11 rounded-xl bg-slate-50 dark:bg-slate-950/50 ring-1 ring-slate-200 dark:ring-slate-800 ps-11 pe-10 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2"
            style={{ '--tw-ring-color': 'var(--ring)' }} />
          {query && <button onClick={() => setQuery('')} aria-label="Clear" className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><IconX size={16} /></button>}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2.5">
          <MiniSelect value={size} onChange={(v) => { setSize(v); setPage(0); }} options={[{ v: '', l: t('anySize') }, { v: '1024×1024', l: '1024×1024' }, { v: '1024×1536', l: '1024×1536' }, { v: '1536×1024', l: '1536×1024' }]} />
          <MiniSelect value={quality} onChange={(v) => { setQuality(v); setPage(0); }} options={[{ v: '', l: t('anyQuality') }, { v: 'high', l: 'high' }, { v: 'medium', l: 'medium' }, { v: 'auto', l: 'auto' }, { v: 'low', l: 'low' }]} />
          <MiniSelect value={bg} onChange={(v) => { setBg(v); setPage(0); }} options={[{ v: '', l: t('anyBg') }, { v: 'auto', l: 'auto' }, { v: 'transparent', l: 'transparent' }]} />
          <span className="text-sm text-slate-400 dark:text-slate-500 ms-1">
            {anyFilter ? `${filtered.length} ${t('matches')}` : `${GALLERY.length} ${t('total')}`}
          </span>
          {anyFilter ? <button onClick={clear} className="ms-auto text-sm font-semibold text-indigo-600 dark:text-indigo-300 hover:underline">{t('clearFilters')}</button> : null}
        </div>

        {/* tag chips */}
        <div className="mt-4 flex flex-wrap gap-2">
          {ALL_TAGS.map(({ tag, count }) => (
            <Chip key={tag} active={activeTags.includes(tag)} onClick={() => toggleTag(tag)}>
              #{tag}<span className="opacity-60">· {count}</span>
            </Chip>
          ))}
        </div>
      </div>

      {/* grid / empty */}
      {view.length === 0 ? (
        <div className="anim-fadeUp text-center py-20">
          <div className="mx-auto grid place-items-center h-16 w-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 mb-4"><IconSearch size={28} /></div>
          <p className="text-lg font-semibold text-slate-700 dark:text-slate-200">{t('noMatch')}</p>
          <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">{t('noMatchSub')}</p>
          <button onClick={clear} className="mt-4 inline-flex"><Btn variant="outline" size="sm">{t('clearFilters')}</Btn></button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
          {view.map((img, i) => <ImageCard key={img.id} img={img} index={i} onOpen={setSelected} />)}
        </div>
      )}

      {/* pagination */}
      {filtered.length > PER && (
        <div className="mt-8 flex items-center justify-between">
          <p className="text-sm text-slate-400 dark:text-slate-500">
            {t('showing')} {page * PER + 1}–{Math.min((page + 1) * PER, filtered.length)} {t('of')} {filtered.length}
          </p>
          <div className="flex items-center gap-2">
            <Btn variant="outline" size="sm" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))} icon={<IconChevronLeft size={16} />}>{t('prev')}</Btn>
            <span className="text-sm font-mono text-slate-500 dark:text-slate-400 px-1">{page + 1} / {pages}</span>
            <Btn variant="outline" size="sm" disabled={page >= pages - 1} onClick={() => setPage((p) => Math.min(pages - 1, p + 1))}>{t('next')}<IconChevronRight size={16} /></Btn>
          </div>
        </div>
      )}

      {selected && <ImageModal img={selected} onClose={() => setSelected(null)} pushToast={pushToast} />}
    </main>
  );
}

Object.assign(window, { GalleryPage, ImageModal, ImageCard });
