// createPage.jsx — Create route: prompt form + preview (states A/B/C). Exported to window.
const { useState, useEffect, useRef, useCallback } = React;

function hashSeed(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0) % 100000;
}
const isArabic = (s) => /[\u0600-\u06FF]/.test(s);

/* ---- progress list ---- */
function StageRow({ stage, status }) {
  // status: 'done' | 'active' | 'pending'
  return (
    <li className={`flex items-start gap-3 transition-opacity duration-300 ${status === 'pending' ? 'opacity-40' : 'opacity-100'}`}>
      <span className="mt-0.5 shrink-0">
        {status === 'done' ? (
          <span className="grid place-items-center h-5 w-5 rounded-full bg-emerald-500 text-white anim-scaleIn"><IconCheck size={13} /></span>
        ) : status === 'active' ? (
          <span className="grid place-items-center h-5 w-5 rounded-full" style={{ '--ring-color': 'rgba(99,102,241,.5)' }}>
            <span className="h-3 w-3 rounded-full pulse-ring" style={{ backgroundColor: 'var(--brand-1)' }} />
          </span>
        ) : (
          <span className="grid place-items-center h-5 w-5 rounded-full ring-1 ring-slate-300 dark:ring-slate-700"><span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-slate-600" /></span>
        )}
      </span>
      <span className="min-w-0">
        <span className={`block text-sm font-medium ${status === 'active' ? 'text-slate-900 dark:text-slate-100' : 'text-slate-700 dark:text-slate-300'}`}>{stage.label}</span>
        <span className="block text-xs text-slate-400 dark:text-slate-500 font-mono mt-0.5">{stage.hint}</span>
      </span>
    </li>
  );
}

/* ---- left: prompt form ---- */
function PromptForm({ prompt, setPrompt, onGenerate, busy, presets, setPresets, onNavigate, pushToast }) {
  const { t, lang } = useApp();
  const [showSimilar, setShowSimilar] = useState(false);
  const [advanced, setAdvanced] = useState(false);
  const [listening, setListening] = useState(false);
  const [opts, setOpts] = useState({ size: '1024×1024', quality: 'auto', background: 'auto', format: 'png', force: false });
  const taRef = useRef(null);

  useEffect(() => { if (listening) { const id = setTimeout(() => setListening(false), 2600); return () => clearTimeout(id); } }, [listening]);

  const togglePreset = (p) => {
    setPresets((prev) => prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]);
  };
  const enhance = () => {
    const add = ', ultra detailed, dramatic lighting, 8k, sharp focus, award-winning composition';
    if (prompt && !prompt.includes('ultra detailed')) setPrompt(prompt + add);
    pushToast('enhanced', 'info');
  };

  const selects = [
    { key: 'size', label: t('size'), opts: ['1024×1024', '1024×1536', '1536×1024', 'auto'] },
    { key: 'quality', label: t('quality'), opts: ['auto', 'low', 'medium', 'high'] },
    { key: 'background', label: t('background'), opts: ['auto', 'transparent', 'opaque'] },
    { key: 'format', label: t('format'), opts: ['png', 'jpeg', 'webp'] },
  ];

  return (
    <div className="rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-800 shadow-xl shadow-slate-200/40 dark:shadow-black/40 p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3 mb-4">
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">{t('describe')}</h2>
        <div className="flex items-center gap-1.5">
          <IconButton label={t('voice')} active={listening} danger={listening} onClick={() => setListening((v) => !v)}>
            <span className="relative">
              <IconMic size={18} />
              {listening && <span className="absolute -top-1 -end-1 h-2 w-2 rounded-full bg-red-500 pulse-ring" style={{ '--ring-color': 'rgba(239,68,68,.5)' }} />}
            </span>
          </IconButton>
          <button onClick={enhance}
            className="inline-flex items-center gap-1.5 h-10 px-3 rounded-xl text-sm font-semibold text-indigo-600 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-500/15 hover:bg-indigo-100 dark:hover:bg-indigo-500/25 transition-colors">
            <IconSparkles size={16} /><span className="hidden sm:inline">{t('enhance')}</span>
          </button>
        </div>
      </div>

      <div className="relative">
        <textarea ref={taRef} dir="auto" rows={5}
          value={prompt} onChange={(e) => { setPrompt(e.target.value); setShowSimilar(e.target.value.length >= 4); }}
          placeholder={t('promptPlaceholder')}
          className="w-full resize-none rounded-xl bg-slate-50 dark:bg-slate-950/50 ring-1 ring-slate-200 dark:ring-slate-800 focus:ring-2 px-4 py-3.5 text-[15px] leading-relaxed text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-600 focus:outline-none transition-shadow"
          style={{ '--tw-ring-color': 'var(--ring)', minHeight: '8.5rem' }} />
        <span className="absolute bottom-2.5 end-3 text-xs font-mono text-slate-400 dark:text-slate-600">{prompt.length} / 4000</span>
      </div>

      {/* similar prompts */}
      {showSimilar && (
        <div className="anim-fadeUp mt-3 rounded-xl ring-1 ring-slate-200 dark:ring-slate-800 overflow-hidden">
          <div className="flex items-center justify-between px-3.5 py-2 bg-slate-50 dark:bg-slate-950/40">
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">{t('similar')}</span>
            <button onClick={() => setShowSimilar(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"><IconChevronDown size={16} /></button>
          </div>
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {SIMILAR_PROMPTS.map((s) => (
              <li key={s.seed}>
                <button onClick={() => { setPrompt(s.prompt); pushToast('copied', 'info'); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-start hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors">
                  <Art seed={s.seed} className="relative h-9 w-9 rounded-lg shrink-0 ring-1 ring-black/5" />
                  <span className="flex-1 min-w-0 text-sm text-slate-600 dark:text-slate-300 truncate">{s.prompt}</span>
                  <Badge color="indigo">{s.sim}%</Badge>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* style presets */}
      <div className="mt-5">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500 mb-2">{t('styles')}</p>
        <div className="flex flex-wrap gap-2">
          {STYLE_PRESETS.map((p) => (
            <Chip key={p} active={presets.includes(p)} onClick={() => togglePreset(p)}>{p}</Chip>
          ))}
        </div>
      </div>

      {/* advanced */}
      <div className="mt-5 rounded-xl ring-1 ring-slate-200 dark:ring-slate-800 overflow-hidden">
        <button onClick={() => setAdvanced((v) => !v)} className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
          {t('advanced')}
          <IconChevronDown size={18} className={`transition-transform duration-300 ${advanced ? 'rotate-180' : ''}`} />
        </button>
        {advanced && (
          <div className="anim-fadeUp px-4 pb-4 pt-1 grid grid-cols-2 gap-3">
            {selects.map((s) => (
              <label key={s.key} className="flex flex-col gap-1.5">
                <span className="text-xs font-medium text-slate-500 dark:text-slate-400">{s.label}</span>
                <select value={opts[s.key]} onChange={(e) => setOpts({ ...opts, [s.key]: e.target.value })}
                  className="h-10 rounded-lg bg-slate-50 dark:bg-slate-950/50 ring-1 ring-slate-200 dark:ring-slate-800 px-3 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2"
                  style={{ '--tw-ring-color': 'var(--ring)' }}>
                  {s.opts.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </label>
            ))}
            <label className="col-span-2 flex items-center gap-2.5 mt-1 cursor-pointer select-none">
              <input type="checkbox" checked={opts.force} onChange={(e) => setOpts({ ...opts, force: e.target.checked })}
                className="h-4 w-4 rounded accent-indigo-500" style={{ accentColor: 'var(--brand-1)' }} />
              <span className="text-sm text-slate-600 dark:text-slate-300">{t('forceRegen')}</span>
            </label>
          </div>
        )}
      </div>

      {/* footer */}
      <div className="mt-6 flex flex-col sm:flex-row sm:items-end gap-4">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-slate-400 dark:text-slate-500 mb-2">{t('samples')}</p>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {SAMPLE_PROMPTS.map((s, i) => (
              <button key={i} onClick={() => setPrompt(s)}
                className="shrink-0 max-w-[12rem] truncate rounded-full px-3 py-1.5 text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                {s}
              </button>
            ))}
          </div>
        </div>
        <Btn size="lg" onClick={onGenerate} disabled={busy || !prompt.trim()} icon={busy ? null : <IconSparkles size={18} />} className="sm:w-auto w-full shrink-0">
          {busy ? t('generating') : t('generate')}
        </Btn>
      </div>
    </div>
  );
}

/* ---- right: preview ---- */
function Preview({ phase, prompt, seed, pass, stageIndex, translated, onCancel, onNavigate, pushToast }) {
  const { t } = useApp();
  const stages = STAGES.filter((s) => !s.conditional || translated);

  if (phase === 'empty') {
    return (
      <div className="rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-800 shadow-xl shadow-slate-200/40 dark:shadow-black/40 p-6 min-h-[28rem] flex flex-col items-center justify-center text-center">
        <div className="relative grid place-items-center h-20 w-20 rounded-2xl bg-slate-50 dark:bg-slate-800/60 ring-1 ring-slate-200 dark:ring-slate-700 mb-5">
          <div className="absolute inset-0 rounded-2xl opacity-10" style={brandGrad} />
          <IconImage size={34} className="text-slate-300 dark:text-slate-600" />
        </div>
        <p className="text-slate-500 dark:text-slate-400 max-w-xs">{t('emptyTitle')}</p>
        <button onClick={() => onNavigate('gallery')} className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-600 dark:text-indigo-300 hover:gap-2.5 transition-all">
          {t('emptyLink')} <IconArrowRight size={15} />
        </button>
      </div>
    );
  }

  const complete = phase === 'complete';

  return (
    <div className="rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-800 shadow-xl shadow-slate-200/40 dark:shadow-black/40 p-5 sm:p-6">
      {/* image area */}
      <div className="relative aspect-square w-full rounded-xl overflow-hidden ring-1 ring-black/5 dark:ring-white/5 bg-slate-100 dark:bg-slate-950">
        {phase === 'streaming' && pass === 0 ? (
          <div className="absolute inset-0 shimmer bg-slate-200 dark:bg-slate-800 grid place-items-center">
            <Spinner size={48} />
          </div>
        ) : (
          <Art key={pass} seed={seed} animate dark className="absolute inset-0" style={{ filter: phase === 'streaming' ? `blur(${(3 - pass) * 4}px)` : 'none' }} />
        )}

        {phase === 'streaming' && pass > 0 && (
          <div className="absolute bottom-3 start-3 anim-fadeIn flex items-center gap-2 rounded-full bg-slate-950/70 backdrop-blur-md px-3 py-1.5 text-xs font-medium text-white">
            <span className="h-2 w-2 rounded-full bg-emerald-400 pulse-ring" style={{ '--ring-color': 'rgba(52,211,153,.5)' }} />
            {t('refining')} {pass}/3
          </div>
        )}
        {complete && (
          <div className="absolute top-3 end-3 anim-fadeIn flex gap-2">
            <Badge color="emerald"><IconCheck size={12} /> {t('saved')}</Badge>
          </div>
        )}
      </div>

      {/* streaming progress list */}
      {phase === 'streaming' && (
        <div className="mt-5 anim-fadeUp">
          <ul className="space-y-3.5">
            {stages.map((s, i) => (
              <StageRow key={s.key} stage={s} status={i < stageIndex ? 'done' : i === stageIndex ? 'active' : 'pending'} />
            ))}
          </ul>
          {translated && (
            <div className="mt-4 anim-fadeUp rounded-xl bg-amber-50 dark:bg-amber-500/10 ring-1 ring-amber-200 dark:ring-amber-500/25 px-4 py-3">
              <p className="text-xs font-semibold text-amber-600 dark:text-amber-300 mb-1">✦ {t('translatedTo')}</p>
              <p className="text-sm text-amber-700 dark:text-amber-200" dir="ltr">{translated}</p>
            </div>
          )}
          <button onClick={onCancel} className="mt-4 text-sm text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">{t('cancel')}</button>
        </div>
      )}

      {/* complete */}
      {complete && (
        <div className="mt-5 anim-fadeUp">
          <div className="flex flex-wrap gap-2">
            <Badge color="indigo">1024×1024</Badge>
            <Badge color="violet">quality: auto</Badge>
            <Badge color="fuchsia">bg: auto</Badge>
            {translated && <Badge color="amber">AR→EN</Badge>}
          </div>
          {translated && (
            <div className="mt-3 rounded-xl bg-amber-50 dark:bg-amber-500/10 ring-1 ring-amber-200 dark:ring-amber-500/25 px-4 py-3">
              <p className="text-xs font-semibold text-amber-600 dark:text-amber-300 mb-1">✦ {t('translatedTo')}</p>
              <p className="text-sm text-amber-700 dark:text-amber-200" dir="ltr">{translated}</p>
            </div>
          )}
          <div className="mt-4 grid grid-cols-3 gap-2.5">
            <Btn variant="outline" size="md" icon={<IconDownload size={17} />} onClick={() => pushToast('downloadStarted', 'success')}>{t('download')}</Btn>
            <Btn variant="outline" size="md" icon={<IconShare size={17} />} onClick={() => pushToast('linkCopied', 'success')}>{t('share')}</Btn>
            <Btn size="md" icon={<IconGrid size={17} />} onClick={() => onNavigate('gallery')}>{t('viewInGallery')}</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

function CreatePage({ onNavigate, pushToast }) {
  const { t } = useApp();
  const [prompt, setPrompt] = useState('');
  const [presets, setPresets] = useState([]);
  const [phase, setPhase] = useState('empty'); // empty | streaming | complete
  const [pass, setPass] = useState(0);
  const [stageIndex, setStageIndex] = useState(0);
  const [translated, setTranslated] = useState(null);
  const [seed, setSeed] = useState(101);
  const timers = useRef([]);

  const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = []; };
  useEffect(() => () => clearTimers(), []);

  const fullPrompt = (prompt + (presets.length ? ', ' + presets.join(', ') + ' style' : '')).trim();

  const generate = () => {
    clearTimers();
    const ar = isArabic(prompt);
    const tr = ar ? 'Futuristic city with neon lights in the rain' : null;
    setTranslated(tr);
    setSeed(hashSeed(fullPrompt) || 101);
    setPhase('streaming');
    setPass(0);
    setStageIndex(0);

    const stages = STAGES.filter((s) => !s.conditional || tr);
    const genIdx = stages.findIndex((s) => s.key === 'generate');
    const T = (fn, d) => timers.current.push(setTimeout(fn, d));

    // advance through pre-generation stages
    let acc = 500;
    for (let i = 1; i <= genIdx; i++) { const idx = i; T(() => setStageIndex(idx), acc); acc += 650; }
    // streaming partials during generate stage
    T(() => setPass(1), acc + 200);
    T(() => setPass(2), acc + 1500);
    T(() => setPass(3), acc + 2800);
    // move to save stage
    T(() => setStageIndex(genIdx + 1), acc + 3600);
    // complete
    T(() => { setPhase('complete'); pushToast('savedToast', 'success'); }, acc + 4400);
  };

  const cancel = () => { clearTimers(); setPhase('empty'); setPass(0); setStageIndex(0); };

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      <div className="grid lg:grid-cols-2 gap-5 lg:gap-6 items-start">
        <div className="anim-fadeUp">
          <PromptForm prompt={prompt} setPrompt={setPrompt} onGenerate={generate} busy={phase === 'streaming'}
            presets={presets} setPresets={setPresets} onNavigate={onNavigate} pushToast={pushToast} />
        </div>
        <div className="anim-fadeUp lg:sticky lg:top-24" style={{ animationDelay: '.08s' }}>
          <Preview phase={phase} prompt={fullPrompt} seed={seed} pass={pass} stageIndex={stageIndex}
            translated={translated} onCancel={cancel} onNavigate={onNavigate} pushToast={pushToast} />
        </div>
      </div>
    </main>
  );
}

Object.assign(window, { CreatePage });
