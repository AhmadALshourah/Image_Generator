// data.jsx — mock data + procedural "AI art" generator, exported to window

/* ---------- seeded PRNG ---------- */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* Generates a premium mesh-gradient "artwork" deterministically from a seed.
   Returns inline-style object. Hue families keep palettes harmonious. */
function genArt(seed, opts = {}) {
  const rnd = mulberry32(seed * 2654435761 % 2147483647 + 7);
  const baseHue = opts.hue != null ? opts.hue : Math.floor(rnd() * 360);
  const sat = 70 + rnd() * 18;
  const blobs = [];
  // guaranteed bright central blob so every artwork reads as vivid
  blobs.push(`radial-gradient(circle at ${(35 + rnd() * 30) | 0}% ${(35 + rnd() * 30) | 0}%, hsla(${baseHue | 0},${sat | 0}%,${(60 + rnd() * 8) | 0}%,0.95) 0%, transparent 65%)`);
  const n = 3 + Math.floor(rnd() * 2);
  for (let i = 0; i < n; i++) {
    const hue = (baseHue + (rnd() * 110 - 55) + i * 28 + 360) % 360;
    const light = 52 + rnd() * 22;
    const x = Math.floor(rnd() * 100);
    const y = Math.floor(rnd() * 100);
    const r = 50 + rnd() * 35;
    const a = 0.7 + rnd() * 0.28;
    blobs.push(`radial-gradient(circle at ${x}% ${y}%, hsla(${hue | 0},${sat | 0}%,${light | 0}%,${a.toFixed(2)}) 0%, transparent ${r | 0}%)`);
  }
  const bgHue = (baseHue + 30) % 360;
  return {
    backgroundColor: `hsl(${bgHue | 0}, ${(sat * 0.7) | 0}%, ${opts.dark ? 28 : 34}%)`,
    backgroundImage: blobs.join(','),
  };
}

/* ---------- style presets ---------- */
const STYLE_PRESETS = [
  'Photorealistic', 'Anime', 'Oil Painting', 'Watercolor',
  'Pixel Art', 'Cinematic', 'Studio Ghibli', '3D Render',
];

/* ---------- sample prompts ---------- */
const SAMPLE_PROMPTS = [
  'A lighthouse on a cliff at golden hour, long exposure waves',
  'Isometric cozy reading nook, soft morning light, 3D render',
  'Neon-lit rainy Tokyo alley, cinematic, shallow depth of field',
  'Minimalist product shot of a ceramic coffee cup on linen',
];

/* ---------- similar-prompt typeahead ---------- */
const SIMILAR_PROMPTS = [
  { seed: 11, prompt: 'A serene mountain lake at sunrise, mist over the water, cinematic', sim: 94 },
  { seed: 24, prompt: 'Mountain landscape with pine forest, golden hour, photorealistic', sim: 88 },
  { seed: 37, prompt: 'Alpine valley with a winding river, dramatic clouds, wide angle', sim: 81 },
  { seed: 52, prompt: 'Snowy mountain peak above the clouds, soft pastel sky', sim: 76 },
];

/* ---------- gallery images ---------- */
const RATIOS = { square: [1, 1], portrait: [4, 5], landscape: [16, 10] };
const SIZE_LABEL = { square: '1024×1024', portrait: '1024×1536', landscape: '1536×1024' };

function mkImg(o) {
  return {
    ratio: 'square', quality: 'auto', background: 'auto', format: 'png',
    cached: false, translated: null, ...o,
    size: SIZE_LABEL[o.ratio || 'square'],
  };
}

const GALLERY = [
  mkImg({ id: 1, seed: 11, hue: 205, ratio: 'landscape', prompt: 'A serene mountain lake at sunrise, mist drifting over the water, cinematic wide shot', tags: ['nature', 'cinematic'], quality: 'high', cost: 0.062, date: 'Jun 2, 2026', fileSize: '1.8 MB' }),
  mkImg({ id: 2, seed: 33, hue: 28, ratio: 'portrait', prompt: 'Portrait of an astronaut, warm rim light, studio background, photorealistic', tags: ['portrait', 'character'], quality: 'high', cost: 0.058, date: 'Jun 2, 2026', fileSize: '1.4 MB' }),
  mkImg({ id: 3, seed: 58, hue: 290, ratio: 'square', prompt: 'مدينة مستقبلية بأضواء نيون تحت المطر', translated: { en: 'Futuristic city with neon lights in the rain' }, tags: ['neon', 'cinematic'], quality: 'medium', cost: 0.034, date: 'Jun 1, 2026', fileSize: '980 KB' }),
  mkImg({ id: 4, seed: 72, hue: 140, ratio: 'square', prompt: 'Studio Ghibli style meadow with wildflowers and a small wooden house', tags: ['anime', 'nature'], quality: 'auto', cost: 0.042, date: 'Jun 1, 2026', fileSize: '1.1 MB', cached: true }),
  mkImg({ id: 5, seed: 91, hue: 15, ratio: 'landscape', prompt: 'Desert dunes at dusk, long shadows, minimal, fine art photography', tags: ['nature', 'cinematic'], quality: 'high', cost: 0.061, date: 'May 31, 2026', fileSize: '1.6 MB' }),
  mkImg({ id: 6, seed: 104, hue: 250, ratio: 'portrait', prompt: 'Anime girl with headphones, city lights bokeh, soft cel shading', tags: ['anime', 'character'], quality: 'medium', cost: 0.033, date: 'May 31, 2026', fileSize: '900 KB' }),
  mkImg({ id: 7, seed: 119, hue: 195, ratio: 'square', prompt: 'Minimalist product shot of a ceramic coffee cup on linen, soft daylight', tags: ['product', '3d'], quality: 'high', cost: 0.059, date: 'May 30, 2026', fileSize: '1.3 MB' }),
  mkImg({ id: 8, seed: 132, hue: 320, ratio: 'square', prompt: 'Abstract liquid metal sculpture, iridescent, 3D render, dark background', tags: ['abstract', '3d'], quality: 'auto', cost: 0.041, date: 'May 30, 2026', fileSize: '1.2 MB' }),
  mkImg({ id: 9, seed: 147, hue: 95, ratio: 'landscape', prompt: 'Watercolor painting of a Tuscan village on a hill, warm palette', tags: ['watercolor', 'architecture'], quality: 'medium', cost: 0.035, date: 'May 29, 2026', fileSize: '1.0 MB' }),
  mkImg({ id: 10, seed: 161, hue: 220, ratio: 'portrait', prompt: 'Cyberpunk samurai in the rain, cinematic lighting, ultra detailed', tags: ['neon', 'character', 'cinematic'], quality: 'high', cost: 0.063, date: 'May 29, 2026', fileSize: '1.7 MB' }),
  mkImg({ id: 11, seed: 178, hue: 35, ratio: 'square', prompt: 'Cozy isometric reading nook, soft morning light, low-poly 3D render', tags: ['3d', 'architecture'], quality: 'auto', cost: 0.042, date: 'May 28, 2026', fileSize: '1.1 MB', cached: true }),
  mkImg({ id: 12, seed: 192, hue: 165, ratio: 'square', prompt: 'لوحة زيتية لغابة في الخريف بألوان دافئة', translated: { en: 'Oil painting of a forest in autumn with warm colors' }, tags: ['nature', 'watercolor'], quality: 'medium', cost: 0.034, date: 'May 28, 2026', fileSize: '1.0 MB' }),
  mkImg({ id: 13, seed: 209, hue: 275, ratio: 'landscape', prompt: 'Galaxy nebula with vivid purples and teals, deep space, ultra wide', tags: ['abstract', 'cinematic'], quality: 'high', cost: 0.062, date: 'May 27, 2026', fileSize: '1.9 MB' }),
  mkImg({ id: 14, seed: 223, hue: 50, ratio: 'portrait', prompt: 'Pixel art knight standing before a castle gate, 16-bit, dramatic sky', tags: ['character', 'abstract'], quality: 'low', cost: 0.018, date: 'May 27, 2026', fileSize: '420 KB' }),
  mkImg({ id: 15, seed: 238, hue: 185, ratio: 'square', prompt: 'Modern architecture, concrete and glass house in a forest, golden hour', tags: ['architecture', 'cinematic'], quality: 'high', cost: 0.06, date: 'May 26, 2026', fileSize: '1.5 MB' }),
  mkImg({ id: 16, seed: 251, hue: 340, ratio: 'square', prompt: 'Floral macro photography, dew on rose petals, soft bokeh', tags: ['nature', 'product'], quality: 'medium', cost: 0.035, date: 'May 26, 2026', fileSize: '1.1 MB' }),
  mkImg({ id: 17, seed: 267, hue: 210, ratio: 'landscape', prompt: 'Stormy ocean waves crashing on rocks, dramatic, black and white', tags: ['nature', 'cinematic'], quality: 'high', cost: 0.061, date: 'May 25, 2026', fileSize: '1.7 MB' }),
  mkImg({ id: 18, seed: 284, hue: 120, ratio: 'portrait', prompt: 'Studio Ghibli forest spirit, glowing particles, dreamy atmosphere', tags: ['anime', 'nature'], quality: 'auto', cost: 0.042, date: 'May 25, 2026', fileSize: '1.2 MB', cached: true }),
  mkImg({ id: 19, seed: 301, hue: 18, ratio: 'square', prompt: 'Vintage car on a desert highway, sunset, cinematic film grain', tags: ['cinematic', 'product'], quality: 'high', cost: 0.059, date: 'May 24, 2026', fileSize: '1.4 MB' }),
  mkImg({ id: 20, seed: 318, hue: 260, ratio: 'square', prompt: 'Abstract 3D fluid shapes, pastel gradient, soft studio lighting', tags: ['abstract', '3d'], quality: 'medium', cost: 0.034, date: 'May 24, 2026', fileSize: '980 KB' }),
];

const ALL_TAGS = (() => {
  const m = {};
  GALLERY.forEach((g) => g.tags.forEach((t) => { m[t] = (m[t] || 0) + 1; }));
  return Object.entries(m).map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count);
})();

/* ---------- stats ---------- */
const STATS = {
  kpis: {
    generated: 47,
    spend: 2.18,
    cacheHits: 9,
    cacheSaved: 0.38,
    translated: 6,
  },
  daily: (() => {
    const rnd = mulberry32(99);
    const out = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date(2026, 5, 3 - i);
      const imgs = Math.floor(rnd() * 5);
      const spend = +(imgs * (0.03 + rnd() * 0.03)).toFixed(3);
      out.push({
        date: `${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`,
        imgs, spend,
      });
    }
    return out;
  })(),
  byQuality: [
    { label: 'high', count: 19 },
    { label: 'medium', count: 14 },
    { label: 'auto', count: 11 },
    { label: 'low', count: 3 },
  ],
  bySize: [
    { label: '1024×1024', count: 22 },
    { label: '1024×1536', count: 13 },
    { label: '1536×1024', count: 9 },
    { label: 'auto', count: 3 },
  ],
};

/* progress stages for the streaming hero */
const STAGES = [
  { key: 'moderate', label: 'Moderating prompt', hint: 'Safety check · ~80ms' },
  { key: 'translate', label: 'Translating to English', hint: 'Arabic detected · gpt-4o-mini', conditional: true },
  { key: 'cache', label: 'Checking cache', hint: 'Hash lookup · no match' },
  { key: 'generate', label: 'Generating image', hint: 'gpt-image-1 · streaming partials' },
  { key: 'save', label: 'Saving + thumbnail', hint: 'Object store + DB write' },
];

Object.assign(window, {
  genArt, mulberry32, STYLE_PRESETS, SAMPLE_PROMPTS, SIMILAR_PROMPTS,
  GALLERY, ALL_TAGS, STATS, STAGES, RATIOS, SIZE_LABEL,
});
