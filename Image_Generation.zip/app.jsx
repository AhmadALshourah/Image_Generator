// app.jsx — root: context provider, routing, theme/lang/palette, toasts, tweaks.

const PALETTES = {
  Aurora: ['#6366f1', '#8b5cf6', '#818cf8'],
  Teal:   ['#0d9488', '#06b6d4', '#2dd4bf'],
  Ember:  ['#ea580c', '#f43f5e', '#fb923c'],
  Orchid: ['#7c3aed', '#db2777', '#c084fc'],
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": ["#6366f1", "#8b5cf6", "#818cf8"],
  "motion": "calm",
  "radius": "soft"
}/*EDITMODE-END*/;

function App() {
  const [route, setRoute] = useState('create');
  const [theme, setTheme] = useState('dark');
  const [lang, setLang] = useState('en');
  const [toasts, setToasts] = useState([]);
  const [tw, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const t = React.useMemo(() => makeT(lang), [lang]);

  // theme
  useEffect(() => {
    const el = document.documentElement;
    el.classList.toggle('dark', theme === 'dark');
    document.body.className = theme === 'dark' ? 'bg-slate-950 theme-anim' : 'bg-slate-50 theme-anim';
  }, [theme]);

  // language / direction
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // palette -> css vars
  useEffect(() => {
    const p = tw.palette || PALETTES.Aurora;
    const root = document.documentElement;
    root.style.setProperty('--brand-1', p[0]);
    root.style.setProperty('--brand-2', p[1]);
    root.style.setProperty('--brand-soft', p[2] || p[1]);
    root.style.setProperty('--ring', p[0]);
  }, [tw.palette]);

  // motion
  useEffect(() => {
    document.documentElement.setAttribute('data-reduce-motion', tw.motion === 'off' ? 'true' : 'false');
  }, [tw.motion]);

  const pushToast = useCallback((key, variant = 'info', customMsg) => {
    const id = Math.random().toString(36).slice(2);
    const msg = customMsg || (key ? makeT(lang)(key) : '');
    setToasts((p) => [...p, { id, msg, variant }]);
    setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 3500);
  }, [lang]);
  const closeToast = (id) => setToasts((p) => p.filter((x) => x.id !== id));

  const ctx = { t, lang, setLang, theme, setTheme };

  const navigate = (r) => { setRoute(r); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  const paletteName = Object.keys(PALETTES).find((k) => PALETTES[k][0] === (tw.palette || [])[0]) || 'Aurora';

  return (
    <AppCtx.Provider value={ctx}>
      <div className="min-h-screen">
        <Header route={route} onNavigate={navigate} />

        <div key={route} className="anim-fadeIn">
          {route === 'create' && <CreatePage onNavigate={navigate} pushToast={pushToast} />}
          {route === 'gallery' && <GalleryPage onNavigate={navigate} pushToast={pushToast} />}
          {route === 'stats' && <StatsPage />}
        </div>

        <Footer />
        <ToastStack toasts={toasts} onClose={closeToast} />

        <TweaksPanel title="Tweaks">
          <TweakSection label="Color palette" />
          <TweakColor label="Brand" value={tw.palette}
            options={Object.values(PALETTES)}
            onChange={(v) => setTweak('palette', v)} />
          <div className="px-1 -mt-1 mb-1 text-[11px] text-slate-400">{paletteName}</div>
          <TweakSection label="Motion" />
          <TweakRadio label="Animations" value={tw.motion} options={['calm', 'off']}
            onChange={(v) => setTweak('motion', v)} />
          <TweakSection label="Quick view" />
          <TweakButton label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} />
          <TweakButton label={lang === 'en' ? 'Switch to العربية (RTL)' : 'Switch to English'} secondary
            onClick={() => setLang(lang === 'en' ? 'ar' : 'en')} />
        </TweaksPanel>
      </div>
    </AppCtx.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
