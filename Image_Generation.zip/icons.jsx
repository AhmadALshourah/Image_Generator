// icons.jsx — lightweight line icons (lucide-style), exported to window
const Ic = (paths, extra = {}) => function Icon({ size = 20, className = '', strokeWidth = 1.75, style }) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      className={className} style={style} aria-hidden="true" {...extra}
    >
      {paths}
    </svg>
  );
};

const IconImage = Ic(<>
  <rect x="3" y="3" width="18" height="18" rx="2.5" />
  <circle cx="8.5" cy="8.5" r="1.5" />
  <path d="M21 15l-5-5L5 21" />
</>);

const IconSparkles = Ic(<>
  <path d="M12 3l1.6 4.6L18 9l-4.4 1.4L12 15l-1.6-4.6L6 9l4.4-1.4L12 3Z" />
  <path d="M19 14l.8 2.2L22 17l-2.2.8L19 20l-.8-2.2L16 17l2.2-.8L19 14Z" />
</>);

const IconMic = Ic(<>
  <rect x="9" y="3" width="6" height="11" rx="3" />
  <path d="M5 11a7 7 0 0 0 14 0" />
  <path d="M12 18v3" />
</>);

const IconChevronDown = Ic(<path d="M6 9l6 6 6-6" />);
const IconChevronRight = Ic(<path d="M9 6l6 6-6 6" />);
const IconChevronLeft = Ic(<path d="M15 6l-6 6 6 6" />);

const IconSearch = Ic(<>
  <circle cx="11" cy="11" r="7" />
  <path d="M21 21l-4.3-4.3" />
</>);

const IconX = Ic(<path d="M6 6l12 12M18 6L6 18" />);

const IconDownload = Ic(<>
  <path d="M12 3v12" />
  <path d="M7 11l5 5 5-5" />
  <path d="M5 21h14" />
</>);

const IconShare = Ic(<>
  <circle cx="18" cy="5" r="2.5" />
  <circle cx="6" cy="12" r="2.5" />
  <circle cx="18" cy="19" r="2.5" />
  <path d="M8.2 10.8l7.6-4.6M8.2 13.2l7.6 4.6" />
</>);

const IconTrash = Ic(<>
  <path d="M4 7h16" />
  <path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2" />
  <path d="M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13" />
</>);

const IconSun = Ic(<>
  <circle cx="12" cy="12" r="4" />
  <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
</>);

const IconMoon = Ic(<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />);

const IconCheck = Ic(<path d="M5 12l4.5 4.5L19 7" strokeWidth="2" />);

const IconGrid = Ic(<>
  <rect x="3" y="3" width="7" height="7" rx="1.5" />
  <rect x="14" y="3" width="7" height="7" rx="1.5" />
  <rect x="3" y="14" width="7" height="7" rx="1.5" />
  <rect x="14" y="14" width="7" height="7" rx="1.5" />
</>);

const IconChart = Ic(<>
  <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
</>);

const IconPlus = Ic(<path d="M12 5v14M5 12h14" />);

const IconGlobe = Ic(<>
  <circle cx="12" cy="12" r="9" />
  <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
</>);

const IconCopy = Ic(<>
  <rect x="9" y="9" width="11" height="11" rx="2" />
  <path d="M5 15V5a2 2 0 0 1 2-2h8" />
</>);

const IconArrowRight = Ic(<path d="M5 12h14M13 6l6 6-6 6" />);

const IconWand = Ic(<>
  <path d="M15 4V2M15 10V8M11 6H9M21 6h-2" />
  <path d="M4 20l11-11 1-1-2-2-1 1L2 18l2 2Z" />
</>);

const IconAlert = Ic(<>
  <path d="M12 9v4M12 17h.01" />
  <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
</>);

const IconRefresh = Ic(<>
  <path d="M3 12a9 9 0 0 1 15-6.7L21 8" />
  <path d="M21 3v5h-5" />
  <path d="M21 12a9 9 0 0 1-15 6.7L3 16" />
  <path d="M3 21v-5h5" />
</>);

const IconLayers = Ic(<>
  <path d="M12 3 3 8l9 5 9-5-9-5Z" />
  <path d="M3 13l9 5 9-5M3 18l9 5 9-5" />
</>);

const IconClock = Ic(<>
  <circle cx="12" cy="12" r="9" />
  <path d="M12 7v5l3 2" />
</>);

Object.assign(window, {
  IconImage, IconSparkles, IconMic, IconChevronDown, IconChevronRight, IconChevronLeft,
  IconSearch, IconX, IconDownload, IconShare, IconTrash, IconSun, IconMoon, IconCheck,
  IconGrid, IconChart, IconPlus, IconGlobe, IconCopy, IconArrowRight, IconWand,
  IconAlert, IconRefresh, IconLayers, IconClock,
});
