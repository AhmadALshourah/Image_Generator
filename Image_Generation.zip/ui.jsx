// ui.jsx — shared UI, i18n, context. Exported to window.
const { createContext, useContext } = React;

/* ---------------- i18n ---------------- */
const TR = {
  // nav / chrome
  brand: { en: 'AI Image Generator', ar: 'مولّد الصور بالذكاء الاصطناعي' },
  tagline: { en: 'Powered by gpt-image-1', ar: 'مدعوم بـ gpt-image-1' },
  create: { en: 'Create', ar: 'إنشاء' },
  gallery: { en: 'Gallery', ar: 'المعرض' },
  stats: { en: 'Stats', ar: 'الإحصائيات' },
  signin: { en: 'Sign in', ar: 'تسجيل الدخول' },
  // create page
  describe: { en: 'Describe your image', ar: 'صِف صورتك' },
  promptPlaceholder: { en: 'A serene mountain lake at sunrise, mist over the water…', ar: 'بحيرة جبلية هادئة عند الشروق، ضباب فوق الماء…' },
  voice: { en: 'Voice input', ar: 'إدخال صوتي' },
  enhance: { en: 'Enhance with AI', ar: 'تحسين بالذكاء الاصطناعي' },
  similar: { en: 'Similar past prompts', ar: 'مطالبات سابقة مشابهة' },
  styles: { en: 'Style presets', ar: 'أنماط جاهزة' },
  advanced: { en: 'Advanced options', ar: 'خيارات متقدمة' },
  forceRegen: { en: 'Force re-generation (skip cache)', ar: 'إعادة التوليد إجباريًا (تجاهل الذاكرة)' },
  size: { en: 'Size', ar: 'الحجم' },
  quality: { en: 'Quality', ar: 'الجودة' },
  background: { en: 'Background', ar: 'الخلفية' },
  format: { en: 'Format', ar: 'الصيغة' },
  generate: { en: 'Generate', ar: 'توليد' },
  generating: { en: 'Generating…', ar: 'جارٍ التوليد…' },
  samples: { en: 'Try a sample', ar: 'جرّب مثالًا' },
  // preview states
  emptyTitle: { en: 'Your generated image will appear here.', ar: 'ستظهر صورتك المولّدة هنا.' },
  emptyLink: { en: 'Or browse your past creations', ar: 'أو تصفّح أعمالك السابقة' },
  refining: { en: 'Refining · pass', ar: 'تحسين · تمريرة' },
  cancel: { en: 'Cancel generation', ar: 'إلغاء التوليد' },
  translatedTo: { en: 'Translated → English (sent to model)', ar: 'تُرجم → الإنجليزية (أُرسل للنموذج)' },
  download: { en: 'Download', ar: 'تنزيل' },
  share: { en: 'Share', ar: 'مشاركة' },
  viewInGallery: { en: 'View in gallery', ar: 'عرض في المعرض' },
  cached: { en: 'Cached', ar: 'من الذاكرة' },
  saved: { en: 'Saved', ar: 'محفوظ' },
  // gallery
  galleryCount: { en: 'images in your collection', ar: 'صورة في مجموعتك' },
  newImage: { en: 'New image', ar: 'صورة جديدة' },
  searchPh: { en: 'Search prompts…', ar: 'ابحث في المطالبات…' },
  anySize: { en: 'Any size', ar: 'أي حجم' },
  anyQuality: { en: 'Any quality', ar: 'أي جودة' },
  anyBg: { en: 'Any background', ar: 'أي خلفية' },
  clearFilters: { en: 'Clear filters', ar: 'مسح الفلاتر' },
  matches: { en: 'matches', ar: 'نتيجة' },
  total: { en: 'total', ar: 'الإجمالي' },
  noMatch: { en: 'No images match your filters', ar: 'لا توجد صور تطابق الفلاتر' },
  noMatchSub: { en: 'Try removing a filter or clearing your search.', ar: 'جرّب إزالة فلتر أو مسح البحث.' },
  showing: { en: 'Showing', ar: 'عرض' },
  of: { en: 'of', ar: 'من' },
  prev: { en: 'Prev', ar: 'السابق' },
  next: { en: 'Next', ar: 'التالي' },
  // modal
  tags: { en: 'Tags', ar: 'الوسوم' },
  addTag: { en: 'Add a tag…', ar: 'أضف وسمًا…' },
  cost: { en: 'Cost', ar: 'التكلفة' },
  created: { en: 'Created', ar: 'أُنشئت' },
  fileSize: { en: 'File size', ar: 'حجم الملف' },
  regenSimilar: { en: 'Regenerate similar', ar: 'إعادة توليد مشابه' },
  delete: { en: 'Delete', ar: 'حذف' },
  confirmDelete: { en: 'Click again to confirm', ar: 'انقر مجددًا للتأكيد' },
  // stats
  usageCost: { en: 'Usage & cost', ar: 'الاستخدام والتكلفة' },
  usageSub: { en: 'All figures are estimates based on gpt-image-1 pricing.', ar: 'جميع الأرقام تقديرية بناءً على تسعير gpt-image-1.' },
  imagesGenerated: { en: 'Images generated', ar: 'الصور المولّدة' },
  totalSpend: { en: 'Total spend', ar: 'إجمالي الإنفاق' },
  cacheHits: { en: 'Cache hits', ar: 'إصابات الذاكرة' },
  autoTranslated: { en: 'Auto-translated', ar: 'تُرجمت تلقائيًا' },
  saved2: { en: 'saved', ar: 'مُوفّر' },
  dailySpend: { en: 'Daily spend · last 30 days', ar: 'الإنفاق اليومي · آخر ٣٠ يومًا' },
  byQuality: { en: 'By quality', ar: 'حسب الجودة' },
  bySize: { en: 'By size', ar: 'حسب الحجم' },
  footer: { en: 'Built with React, TypeScript, Tailwind CSS, TanStack Query, and FastAPI.', ar: 'مبني بـ React وTypeScript وTailwind CSS وTanStack Query وFastAPI.' },
  copied: { en: 'Prompt copied to your editor.', ar: 'تم نسخ المطالبة إلى المحرّر.' },
  enhanced: { en: 'Prompt expanded with more detail.', ar: 'تم توسيع المطالبة بمزيد من التفاصيل.' },
  downloadStarted: { en: 'Download started (1024×1024 PNG).', ar: 'بدأ التنزيل (PNG ‎1024×1024).' },
  linkCopied: { en: 'Shareable link copied to clipboard.', ar: 'تم نسخ رابط المشاركة.' },
  deleted: { en: 'Image deleted from your gallery.', ar: 'تم حذف الصورة من معرضك.' },
  savedToast: { en: 'Saved to your gallery.', ar: 'حُفظت في معرضك.' },
};

function makeT(lang) {
  return (key, fallback) => (TR[key] && TR[key][lang]) || fallback || key;
}

/* ---------------- context ---------------- */
const AppCtx = createContext(null);
const useApp = () => useContext(AppCtx);

const brandGrad = { backgroundImage: 'linear-gradient(135deg, var(--brand-1), var(--brand-2))' };

/* ---------------- art ---------------- */
function Art({ seed, hue, dark, className = '', style = {}, animate = false }) {
  const art = genArt(seed, { hue, dark });
  return (
    <div
      className={`${className} ${animate ? 'anim-reveal' : ''}`}
      style={{
        ...art,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        ...style,
      }}
    >
      {/* grain + vignette overlay */}
      <div className="absolute inset-0 pointer-events-none" style={{
        backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.4'/%3E%3C/svg%3E\")",
        mixBlendMode: 'overlay', opacity: 0.12,
      }} />
      <div className="absolute inset-0 pointer-events-none" style={{
        background: 'radial-gradient(circle at 50% 35%, transparent 55%, rgba(0,0,0,.18) 100%)',
      }} />
    </div>
  );
}

/* ---------------- primitives ---------------- */
function Badge({ children, color = 'slate', soft = true }) {
  const map = {
    indigo: 'text-indigo-600 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-500/15 ring-indigo-200 dark:ring-indigo-500/25',
    violet: 'text-violet-600 dark:text-violet-300 bg-violet-50 dark:bg-violet-500/15 ring-violet-200 dark:ring-violet-500/25',
    fuchsia: 'text-fuchsia-600 dark:text-fuchsia-300 bg-fuchsia-50 dark:bg-fuchsia-500/15 ring-fuchsia-200 dark:ring-fuchsia-500/25',
    emerald: 'text-emerald-600 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-500/15 ring-emerald-200 dark:ring-emerald-500/25',
    amber: 'text-amber-600 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/15 ring-amber-200 dark:ring-amber-500/25',
    red: 'text-red-600 dark:text-red-300 bg-red-50 dark:bg-red-500/15 ring-red-200 dark:ring-red-500/25',
    slate: 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 ring-slate-200 dark:ring-slate-700',
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ${map[color]}`}>
      {children}
    </span>
  );
}

function Btn({ children, variant = 'primary', size = 'md', className = '', icon, ...props }) {
  const sizes = { sm: 'h-9 px-3.5 text-sm gap-1.5', md: 'h-11 px-5 text-sm gap-2', lg: 'h-12 px-6 text-base gap-2' };
  const base = `inline-flex items-center justify-center font-semibold rounded-xl transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-transparent disabled:opacity-50 disabled:cursor-not-allowed ${sizes[size]} ${className}`;
  if (variant === 'primary') {
    return (
      <button className={`${base} text-white shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 hover:-translate-y-0.5 active:translate-y-0`}
        style={{ ...brandGrad, '--tw-ring-color': 'var(--ring)' }} {...props}>
        {icon}{children}
      </button>
    );
  }
  const variants = {
    ghost: 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800',
    outline: 'text-slate-700 dark:text-slate-200 ring-1 ring-slate-200 dark:ring-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800',
    danger: 'text-red-600 dark:text-red-400 ring-1 ring-red-200 dark:ring-red-500/30 hover:bg-red-50 dark:hover:bg-red-500/10',
  };
  return <button className={`${base} ${variants[variant]}`} style={{ '--tw-ring-color': 'var(--ring)' }} {...props}>{icon}{children}</button>;
}

function IconButton({ label, active, danger, className = '', children, ...props }) {
  return (
    <button aria-label={label} title={label}
      className={`inline-flex items-center justify-center h-10 w-10 rounded-xl transition-all duration-200 focus:outline-none focus-visible:ring-2
        ${danger ? 'text-red-500 bg-red-50 dark:bg-red-500/15' : active
          ? 'text-indigo-600 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-500/15'
          : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'} ${className}`}
      style={{ '--tw-ring-color': 'var(--ring)' }} {...props}>
      {children}
    </button>
  );
}

function Chip({ children, active, onClick, className = '', ...props }) {
  return (
    <button onClick={onClick}
      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-medium transition-all duration-200 focus:outline-none focus-visible:ring-2
        ${active
          ? 'text-white shadow-md shadow-indigo-500/20'
          : 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 ring-1 ring-transparent'} ${className}`}
      style={{ ...(active ? brandGrad : {}), '--tw-ring-color': 'var(--ring)' }} {...props}>
      {children}
    </button>
  );
}

function Spinner({ size = 56 }) {
  const { t } = useApp();
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative" style={{ width: size, height: size }}>
        <div className="absolute inset-0 rounded-full blur-md opacity-50" style={brandGrad} />
        <div className="absolute inset-0 rounded-full" style={{
          background: 'conic-gradient(from 0deg, transparent, var(--brand-1), var(--brand-2))',
          mask: 'radial-gradient(farthest-side, transparent calc(100% - 4px), #000 0)',
          WebkitMask: 'radial-gradient(farthest-side, transparent calc(100% - 4px), #000 0)',
        }} />
        <div className="spin absolute inset-0 rounded-full" style={{
          background: 'conic-gradient(from 0deg, transparent 70%, var(--brand-2))',
          mask: 'radial-gradient(farthest-side, transparent calc(100% - 4px), #000 0)',
          WebkitMask: 'radial-gradient(farthest-side, transparent calc(100% - 4px), #000 0)',
        }} />
      </div>
    </div>
  );
}

/* ---------------- header ---------------- */
function Header({ route, onNavigate }) {
  const { t, lang, setLang, theme, setTheme } = useApp();
  const nav = [
    { key: 'create', icon: <IconSparkles size={17} /> },
    { key: 'gallery', icon: <IconGrid size={17} /> },
    { key: 'stats', icon: <IconChart size={17} /> },
  ];
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/70 dark:border-slate-800/70 bg-white/70 dark:bg-slate-950/70 backdrop-blur-xl">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center gap-3">
        <button onClick={() => onNavigate('create')} className="flex items-center gap-3 min-w-0">
          <span className="grid place-items-center h-9 w-9 rounded-xl text-white shadow-lg shadow-indigo-500/30 shrink-0" style={brandGrad}>
            <IconImage size={19} />
          </span>
          <span className="hidden sm:flex flex-col items-start leading-tight min-w-0">
            <span className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">{t('brand')}</span>
            <span className="text-[11px] text-slate-400 dark:text-slate-500 truncate">{t('tagline')}</span>
          </span>
        </button>

        <nav className="flex items-center gap-1 mx-auto sm:mx-0 sm:ms-6">
          {nav.map((n) => (
            <button key={n.key} onClick={() => onNavigate(n.key)}
              className={`inline-flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-medium transition-all duration-200
                ${route === n.key ? 'text-white shadow-md shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
              style={route === n.key ? brandGrad : {}}>
              {n.icon}<span className="hidden xs:inline sm:inline">{t(n.key)}</span>
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-1.5 ms-auto">
          <button onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
            aria-label="Toggle language"
            className="inline-flex items-center gap-1.5 h-10 px-3 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <IconGlobe size={17} />
            <span>{lang === 'en' ? 'ع' : 'EN'}</span>
          </button>
          <IconButton label="Toggle theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
            {theme === 'dark' ? <IconSun size={19} /> : <IconMoon size={19} />}
          </IconButton>
          <button className="hidden sm:inline-flex items-center h-10 px-4 rounded-xl text-sm font-semibold text-white ms-1" style={brandGrad}>
            {t('signin')}
          </button>
        </div>
      </div>
    </header>
  );
}

function Footer() {
  const { t } = useApp();
  return (
    <footer className="max-w-6xl mx-auto px-6 py-10 text-center">
      <p className="text-xs text-slate-400 dark:text-slate-600">{t('footer')}</p>
    </footer>
  );
}

/* ---------------- toasts ---------------- */
function ToastStack({ toasts, onClose }) {
  const styleMap = {
    success: { ring: 'ring-emerald-200 dark:ring-emerald-500/30', dot: 'text-emerald-500', icon: <IconCheck size={16} /> },
    error: { ring: 'ring-red-200 dark:ring-red-500/30', dot: 'text-red-500', icon: <IconAlert size={16} /> },
    info: { ring: 'ring-slate-200 dark:ring-slate-700', dot: 'text-slate-400', icon: <IconSparkles size={16} /> },
  };
  return (
    <div className="fixed top-20 inset-x-0 sm:inset-x-auto sm:end-6 z-50 flex flex-col items-center sm:items-end gap-2.5 px-4 pointer-events-none">
      {toasts.map((tt) => {
        const s = styleMap[tt.variant] || styleMap.info;
        return (
          <div key={tt.id}
            className={`anim-slideIn pointer-events-auto flex items-center gap-3 max-w-sm rounded-xl bg-white dark:bg-slate-900 ring-1 ${s.ring} shadow-xl shadow-black/10 dark:shadow-black/40 px-4 py-3`}>
            <span className={`grid place-items-center h-6 w-6 rounded-full bg-slate-50 dark:bg-slate-800 ${s.dot}`}>{s.icon}</span>
            <span className="text-sm text-slate-700 dark:text-slate-200">{tt.msg}</span>
            <button onClick={() => onClose(tt.id)} aria-label="Dismiss"
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 ms-1"><IconX size={15} /></button>
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, {
  AppCtx, useApp, makeT, TR, brandGrad,
  Art, Badge, Btn, IconButton, Chip, Spinner, Header, Footer, ToastStack,
});
